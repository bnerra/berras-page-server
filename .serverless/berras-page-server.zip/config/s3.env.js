const env = {
  AWS_ACCESS_KEY: '',
  AWS_SECRET_ACCESS_KEY: '',
  REGION: 'us-east-1',
  Bucket: 'bnerra.com'
};

module.exports = env;