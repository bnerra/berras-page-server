A serverless node.js endpoint for berras-page.

To deploy to AWS Lambda:
'serverless deploy'